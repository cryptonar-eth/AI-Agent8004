from __future__ import annotations
import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

STATE_FILE = Path("logs/state.json")

@dataclass
class AgentState:
    equity_usd: float = 1000.0
    daily_pnl_usd: float = 0.0
    day_key: str = ""
    last_trade_ts_ms_by_symbol: dict[str, int] = None

    def __post_init__(self) -> None:
        if self.last_trade_ts_ms_by_symbol is None:
            self.last_trade_ts_ms_by_symbol = {}

def _today_key() -> str:
    # simple UTC day key; good enough for now
    return time.strftime("%Y-%m-%d", time.gmtime())

def load_state() -> AgentState:
    if not STATE_FILE.exists():
        s = AgentState(day_key=_today_key())
        save_state(s)
        return s

    data = json.loads(STATE_FILE.read_text(encoding="utf-8"))
    s = AgentState(
        equity_usd=float(data.get("equity_usd", 1000.0)),
        daily_pnl_usd=float(data.get("daily_pnl_usd", 0.0)),
        day_key=str(data.get("day_key", _today_key())),
        last_trade_ts_ms_by_symbol=dict(data.get("last_trade_ts_ms_by_symbol", {})),
    )

    # reset daily pnl if day changed
    if s.day_key != _today_key():
        s.day_key = _today_key()
        s.daily_pnl_usd = 0.0
        save_state(s)

    return s

def save_state(state: AgentState) -> None:
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    data: dict[str, Any] = {
        "equity_usd": state.equity_usd,
        "daily_pnl_usd": state.daily_pnl_usd,
        "day_key": state.day_key,
        "last_trade_ts_ms_by_symbol": state.last_trade_ts_ms_by_symbol,
    }
    STATE_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
