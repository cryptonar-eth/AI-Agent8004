from __future__ import annotations
from agent.config.settings import Settings
from agent.core.proposals import Proposal, ProposalType
from agent.governance.approvals import is_approved
from agent.governance.policy import check_trade
from agent.ops.killswitch import is_killed
from agent.ops.audit import log
from agent.storage.state_store import load_state
from agent.trading.risk_state import check_trade_pct, record_trade_timestamp

class Executor:
    def __init__(self, settings: Settings):
        self.settings = settings

    def execute(self, proposal: Proposal) -> None:
        if is_killed():
            log("blocked_killswitch", {"proposal_id": proposal.proposal_id, "type": proposal.type})
            print("[EXEC] BLOCKED: kill switch enabled")
            return

        if proposal.type == ProposalType.TRADE:
            symbol = str(proposal.payload.get("symbol"))
            side = str(proposal.payload.get("side"))
            qty = float(proposal.payload.get("qty"))

            # Basic governance checks
            ok, reason = check_trade(symbol, qty)
            if not ok:
                log("blocked_governance", {"proposal_id": proposal.proposal_id, "reason": reason, "payload": proposal.payload})
                print(f"[EXEC] BLOCKED: governance: {reason}")
                return

            # Load state for % risk checks
            state = load_state()

            # TEMP: estimate notional (USD) using a placeholder price in payload if present
            # Later: use real market data snapshot pricing.
            price = float(proposal.payload.get("price_usd", 3500.0))
            est_notional_usd = qty * price

            rd = check_trade_pct(state, symbol, est_notional_usd)
            if not rd.ok:
                log("blocked_risk_pct", {"proposal_id": proposal.proposal_id, "reason": rd.reason, "notional_usd": est_notional_usd})
                print(f"[EXEC] BLOCKED: risk: {rd.reason}")
                return

            # Approval required only when autonomy is OFF
            if not self.settings.auto_execute_trades:
                if not is_approved(proposal.proposal_id):
                    log("blocked_no_approval", {"proposal_id": proposal.proposal_id, "payload": proposal.payload})
                    print(f"[EXEC] BLOCKED: not approved. Create approvals/{proposal.proposal_id}.approved")
                    return

            if self.settings.dry_run:
                log("dry_run_trade", {"proposal_id": proposal.proposal_id, "payload": proposal.payload, "reason": proposal.reason})
                record_trade_timestamp(state, symbol)
                mode = "AUTO" if self.settings.auto_execute_trades else "APPROVAL"
                print(f"[EXEC] DRY_RUN ({mode}) TRADE: {side} {qty} {symbol} @~{price} :: {proposal.reason}")
                return

            raise NotImplementedError("Live execution not implemented yet")

        log("blocked_unknown_type", {"proposal_id": proposal.proposal_id, "type": proposal.type})
        print(f"[EXEC] BLOCKED: unsupported proposal type: {proposal.type}")
