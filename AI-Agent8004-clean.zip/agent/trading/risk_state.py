from __future__ import annotations
from dataclasses import dataclass
import time

from agent.storage.state_store import AgentState, save_state

@dataclass(frozen=True)
class RiskPctRules:
    max_risk_per_trade_pct: float = 0.02      # 2%
    max_daily_loss_pct: float = 0.03          # 3%
    cooldown_seconds: int = 120               # 2 minutes between trades per symbol
    max_exposure_pct: float = 0.20            # 20% total exposure cap (placeholder)

@dataclass(frozen=True)
class RiskDecision:
    ok: bool
    reason: str

def _now_ms() -> int:
    return int(time.time() * 1000)

def check_trade_pct(
    state: AgentState,
    symbol: str,
    est_notional_usd: float,
    rules: RiskPctRules = RiskPctRules(),
) -> RiskDecision:
    # Daily loss circuit breaker
    max_daily_loss_usd = state.equity_usd * rules.max_daily_loss_pct
    if state.daily_pnl_usd <= -max_daily_loss_usd:
        return RiskDecision(False, f"Daily loss limit hit: pnl={state.daily_pnl_usd:.2f} <= -{max_daily_loss_usd:.2f}")

    # Per-trade risk cap (using notional as proxy for now)
    max_trade_usd = state.equity_usd * rules.max_risk_per_trade_pct
    if est_notional_usd > max_trade_usd:
        return RiskDecision(False, f"Trade too large vs equity: {est_notional_usd:.2f} > {max_trade_usd:.2f} (risk pct cap)")

    # Cooldown per symbol
    last_ms = state.last_trade_ts_ms_by_symbol.get(symbol)
    if last_ms is not None:
        dt = (_now_ms() - last_ms) / 1000.0
        if dt < rules.cooldown_seconds:
            return RiskDecision(False, f"Cooldown active for {symbol}: wait {rules.cooldown_seconds - int(dt)}s")

    return RiskDecision(True, "OK")

def record_trade_timestamp(state: AgentState, symbol: str) -> None:
    state.last_trade_ts_ms_by_symbol[symbol] = _now_ms()
    save_state(state)
